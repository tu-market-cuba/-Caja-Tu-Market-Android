package com.tumarket.caja;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST = 41;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        requestNeededPermissions();
        webView.loadUrl("file:///android_asset/web/caja.html");
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.CAMERA}, PERMISSION_REQUEST);
        } else if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST);
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class PrinterBridge {
        @JavascriptInterface public void printReceipt(String text) {
            new Thread(() -> {
                String result;
                try { printToMhtP11(text); result = "Impresión enviada a MHT-P11"; }
                catch (Exception error) { result = "No se pudo imprimir: " + error.getMessage(); }
                String message = result;
                runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
            }).start();
        }

        @JavascriptInterface public boolean isAvailable() { return true; }
    }

    @SuppressLint("MissingPermission")
    private void printToMhtP11(String receipt) throws Exception {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new Exception("esta tableta no tiene Bluetooth");
        if (!adapter.isEnabled()) throw new Exception("enciende el Bluetooth");
        BluetoothDevice printer = findPrinter(adapter.getBondedDevices());
        if (printer == null) throw new Exception("empareja primero la impresora MHT-P11");
        try (BluetoothSocket socket = printer.createRfcommSocketToServiceRecord(SPP)) {
            socket.connect();
            OutputStream out = socket.getOutputStream();
            out.write(new byte[]{0x1B, 0x40});
            out.write(receipt.getBytes(Charset.forName("CP437")));
            out.write(new byte[]{0x0A, 0x0A, 0x0A});
            out.flush();
        }
    }

    private BluetoothDevice findPrinter(Set<BluetoothDevice> devices) {
        BluetoothDevice fallback = null;
        for (BluetoothDevice device : devices) {
            String name = device.getName() == null ? "" : device.getName().toUpperCase();
            if (name.contains("MHT-P11") || name.contains("MHT_P11")) return device;
            if (fallback == null && (name.contains("PRINTER") || name.contains("MHT"))) fallback = device;
        }
        return fallback;
    }
}
