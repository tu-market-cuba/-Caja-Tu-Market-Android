# Tu Market Caja does not require custom ProGuard rules.
